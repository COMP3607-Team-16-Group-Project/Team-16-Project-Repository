//Javonte Baldeo 
//Student ID: 816036030
//Assignment 1
import java.util.ArrayList;

public class ChatBot{
    //Attributes
    private String chatBotName;
    private int numResponsesGenerated;
    private static int messageLimit = 10;
    private static int messageNumber = 0;

    //Methods
    public ChatBot(){
        this.chatBotName = "ChatGPT-3.5";
        this.numResponsesGenerated = 0;
    }

    public ChatBot(int LLMCode){
        this.chatBotName = ChatBotGenerator.generateChatBotLLM(LLMCode);
        this.numResponsesGenerated = 0;
    }

    public String getChatBotName(){
        return chatBotName;
    }

    public int getNumResponsesGenerated(){
        return numResponsesGenerated;
    }

    public static int getTotalNumResponsesGenerated(){
        return messageNumber;
    }

    public static int getTotalNumMessagesRemaining(){
        return messageLimit - messageNumber;
    }

    public static boolean limitReached(){
        return messageNumber >= messageLimit;
    }

    private String generateResponse(){
        if (!limitReached()){
            messageNumber++;
            numResponsesGenerated++;
            return "(Message# " + messageNumber + ") Response from " + chatBotName + " >> generatedTextHere";
        }else{
            return "Daily Limit Reached. Wait 24 hours to resume chatbot usage";
        }
    }

    public String prompt(String requestMessage){
        return generateResponse();
    }


    public String toString(){
        return "ChatBot Name: " + chatBotName + " Number Messages Used: " + numResponsesGenerated;
    }
}