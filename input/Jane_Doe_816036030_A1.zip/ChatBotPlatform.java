//Javonte Baldeo 
//Student ID: 816036030
//Assignment 1
import java.util.ArrayList;

public class ChatBotPlatform{
    private ArrayList<ChatBot> bots;

    public ChatBotPlatform(){
        this.bots = new ArrayList<>();
    }

    public boolean addChatBot(int LLMcode){
        if (!ChatBot.limitReached()) {
            ChatBot newBot = new ChatBot(LLMcode);
            bots.add(newBot);
            return true;
        } else{
            return false;
        }
    }

    //Used StringBuilder and append() to concatenate strings more efficiently
    public String getChatBotList() {
        StringBuilder info = new StringBuilder();
        info.append("ChatBots:\n");
        for (int i = 0; i < bots.size(); i++) {
            info.append("Index ").append(i).append(": ").append(bots.get(i)).append("\n");
        }
        info.append("Summary Usage Statistics:\n");
        info.append("Total Messages Sent: ").append(ChatBot.getTotalNumResponsesGenerated()).append("\n");
        info.append("Remaining Messages: ").append(ChatBot.getTotalNumMessagesRemaining()).append("\n");
        return info.toString();
    }





    public String interactWithBot(int botNumber, String message){
        if(botNumber < 0 || botNumber >= bots.size()){
            return "Incorrect Bot Number (" + botNumber + ") Selected. Try again";
        } else{
            return bots.get(botNumber).prompt(message);
        }
    }
}

//StringBuilder and append() techniques were sourced and found at https://www.javatpoint.com/StringBuilder-class
