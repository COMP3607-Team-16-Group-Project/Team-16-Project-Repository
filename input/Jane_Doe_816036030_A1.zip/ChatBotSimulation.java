//Javonte Baldeo 
//Student ID: 816036030
//Assignment 1
import java.util.Random;

public class ChatBotSimulation {
    public static void main(String[] args) {
        System.out.println("Hello World!");
        System.out.println("----------------------");

        //Initialize ChatBotPlatform
        ChatBotPlatform platform = new ChatBotPlatform();

        //ChatBot objects
        platform.addChatBot(1);//LLaMa
        platform.addChatBot(2);//Mistral7B
        platform.addChatBot(3);//Bard
        platform.addChatBot(4);//Claude
        platform.addChatBot(5);//Solar

        //List of ChatBots
        System.out.println("Your ChatBots");
        System.out.println(platform.getChatBotList());
        System.out.println("----------------------");

        //Choose random ChatBots
        Random random = new Random();
        for (int i = 0; i < 15; i++) {
            int botNumber = random.nextInt(platform.getChatBotList().split("\n").length - 3); // -3 for summary lines
            String message = "Sample message";
            String response = platform.interactWithBot(botNumber, message);
            System.out.println(response);
        }

        
        System.out.println("----------------------");
        System.out.println("Your ChatBots");
        System.out.println(platform.getChatBotList());
        System.out.println("----------------------");
    }
}
