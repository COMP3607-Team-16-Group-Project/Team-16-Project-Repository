/*
Student I.D.: 816024202
*/

public class ChatBot
{
    //Attributes:
    
    //Instance Attributes:
    private String chatBotName;
    private int numResponsesGenerated;
    
    
    //Class Attributes:
    private static int messageLimit = 10;
    private static int messageNumber = 0;
    
    
    
    //Methods:
    
    //Constructor Methods:
    public ChatBot()
    {
        chatBotName = ChatBotGenerator.generateChatBotLLM(0);
        numResponsesGenerated = 0;
    }
    
    public ChatBot(int LLMCode)
    {
        chatBotName = ChatBotGenerator.generateChatBotLLM(LLMCode);
        numResponsesGenerated = 0;
    }
    
    
    //Accessor Methods:
    public String getChatBotName()
    {
        return this.chatBotName;
    }
    
    public int getNumResponsesGenerated()
    {
        return this.numResponsesGenerated;
    }
    
    public static int getTotalNumResponsesGenerated()
    {
        return messageNumber;
    }
    
    public static int getmessageLimit()
    {
        return messageLimit;
    }
    
    
    //Other Methods:
    public static int getTotalNumMessagesRemaining()
    {
        return (messageLimit - messageNumber);
    }
    
    public static boolean limitReached()
    {
        if (getTotalNumMessagesRemaining() == 0)
        {
            return true;
        }
        return false;
    }
    
    private String generateResponse()
    {
        this.numResponsesGenerated++;
        messageNumber++;
        return ("(Message# " + messageNumber + ") Response from " + this.chatBotName + "    >>generatedTextHere" + "/n");
    }
    
    public String prompt(String requestMessage)
    {
        if(!limitReached())
        {
            return (generateResponse());
        }
        return ("Daily Limit Reached. Wait 24 hours to resume chatbot usage");
    }
    
    public String toString()
    {
        return ("ChatBot Name: " + this.chatBotName + "    Number Messages used: " + this.numResponsesGenerated);
    }
}
