/*
Student I.D.: 816024202
*/

//Import Statements:
import java.util.ArrayList;

public class ChatBotPlatform
{
    //Attributes:
    
    //Instance Attributes:
    private ArrayList<ChatBot> bots;
    
    
    
    //Methods:
    
    //Constructor Methods:
    public ChatBotPlatform()
    {
        this.bots = new ArrayList<ChatBot>();
    }
    
    //Other Methods:
    public boolean addChatBot(int LLMCode)
    {
        if(!(ChatBot.limitReached()))
        {
            ChatBot newChatBot = new ChatBot(LLMCode);
            this.bots.add(newChatBot);
            
            return true;
        }
        return false;
    }
    
    public String getChatBotList()
    {
        StringBuilder output = new StringBuilder();
        
        output.append("----------------------\n Your ChatBots\n");
        
        for (int i = 0; i < (this.bots.size()); i++)
        {
            output.append("Bot Number: ").append(i).append(" chatBot Name: ").append(this.bots.get(i).getChatBotName()).append(" Number Messages Used: ").append(this.bots.get(i).getNumResponsesGenerated()).append("\n");
        }
        
        output.append("Total Messages Used: ").append(ChatBot.getTotalNumResponsesGenerated()).append("\n");
        output.append("Total Messages Remaining: ").append(ChatBot.getTotalNumMessagesRemaining()).append("\n----------------------\n");
        
        return output.toString();
    }
    
    public String interactWithBot(int botNumber, String message)
    {
        if ((botNumber < 0) || (botNumber >= (this.bots.size())))
        {
            return ("Incorrect Bot Number (" + botNumber + ") Selected. Try again");
        }
            return (this.bots.get(botNumber).prompt(message));
    }
}
