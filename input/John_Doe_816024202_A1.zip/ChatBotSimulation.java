/*
Student Name: Teal Trim
Student I.D.: 816024202
Programme of Study: B.Sc. Computer Science with Management
Course Name: Object-Oriented Programming I
Course Code: COMP2603
Semester: Semester 2
Assignment: Assignment 1
Date: 07/02/2024
*/

public class ChatBotSimulation
{
    public static void main (String[] args)
    {
        System.out.println("Hello World!");
        
        ChatBotPlatform newChatBotPlatform = new ChatBotPlatform();
        
        for (int i = 0; i < 6; i++)
        {
            try
            {
                newChatBotPlatform.addChatBot(i);
            }
            catch (Exception e)
            {
                System.out.println("Failed to add bot: " + i);
            }
        }
        
        System.out.print(newChatBotPlatform.getChatBotList());
        
        String message = "Message.";
        
        for (int i = 0; i < 15; i++)
        {
            System.out.println(newChatBotPlatform.interactWithBot(getRandomNumber(0, 7), message));
        }
        
        System.out.print(newChatBotPlatform.getChatBotList());
    }
    
    public static int getRandomNumber(int min, int max)
    {
        return (int) ((Math.random()*(max-min))+min);
    }
}

/*
Sources:
https://www.baeldung.com/java-static#:~:text=It%20doesn't%20matter%20how,of%20either%20the%20same%20class.
https://www.w3schools.com/
https://stackify.com/top-java-software-errors/#:~:text=7.,stated%20in%20the%20method%20signature.
https://linuxhint.com/call-invoke-method-from-another-class-java/
https://www.baeldung.com/java-method-in-javadoc#:~:text=Referencing%20a%20Method%20in%20Another%20Class&text=The%20syntax%20is%20similar%20to,class%20name%20before%20the%20%23%20symbol.&text=In%20this%20case%2C%20the%20Vehicle,referencing%20the%20Vehicle()%20method.
https://ioflood.com/blog/length-of-arraylist-java/#:~:text=The%20length%20of%20an%20ArrayList%20in%20Java%20can%20be%20found,elements%20present%20in%20the%20ArrayList.
https://www.simplilearn.com/tutorials/java-tutorial/static-keyword-in-java#:~:text=Static%20keyword%20in%20java%20in,create%20one%20instance%20of%20it.
https://stackoverflow.com/questions/7833689/how-can-i-print-a-string-adding-newlines-in-java
https://www.javatpoint.com/StringBuilder-class
COMP2603 Lecture Notes.
COMP2603 Lab Solutions.
*/
